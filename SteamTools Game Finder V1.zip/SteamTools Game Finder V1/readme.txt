Still in development so bugs are expected!

When typing the game name, try enter it as best as you can.

Even if you spell it a bit wrong, it can still auto find the game you were trying to spell.

https://github.com/tinykian7/Steam-Tools-Game-Finder

Made By tinykian7